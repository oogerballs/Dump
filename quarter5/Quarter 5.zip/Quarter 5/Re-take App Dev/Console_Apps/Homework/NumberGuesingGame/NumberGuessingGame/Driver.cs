﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberGuessingGame
{
    class Driver
    {
        static void Main(string[] args)
        {
            Runner.Run(args);
        }
    }
}
