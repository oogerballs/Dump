﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberGuessingGame
{
    class Runner
    {
        static Random rand = new Random();
        static bool AllowSound = false;
        public static void Run(String[] args)
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.Clear();            
            SetBeep(args);
            bool cont = true; 
            do
            {
                int maxNum = TakeLongInput("Please enter the maximum number for the guessing game", 1, int.MaxValue-1);
                GuessingGame(maxNum);
                long replayOption = TakeLongInput("\nWould you like to play again? enter 1 for yes or 2 for no.\n", 1, 3);
                if(replayOption == 2)
                {
                    cont = false;
                }
                else
                {
                    Console.Clear();

                }

            } while (cont == true);
        }

        private static void SetBeep(String[] args)
        {
            if(args.Length > 0)
            {
                foreach (String arg in args)
                {
                    if(arg == "Sound" || arg == "sound")
                    {
                        AllowSound = true;
                    }
                }
            }
        }

        private static void PlayBeep(bool isCorrect)
        {
            if (AllowSound == true)
            {
                if (isCorrect == true)
                {
                    Console.Beep(5200,100);
                }
                else
                {
                    Console.Beep(500, 100);
                }

            }
        }

        private static int TakeLongInput(String prompt, long min, long max)
        {
            bool validInput = false;
            int res = 0;
            do
            {
                Console.WriteLine(prompt);
                String input = Console.ReadLine();
                if (int.TryParse(input, out int longput))
                {
                    res = longput;
                    if(res < min || res > max)
                    {
                        PlayBeep(false);
                        Console.WriteLine($"Your input was invalid. Please enter a number between {min} and {max}");
                    }
                    else
                    {
                    validInput = true;
                    }
                }
                else
                {
                    PlayBeep(false);
                    Console.WriteLine("Your input was invalid");
                }
            } while(validInput == false);
                return res;
        }

        private static void GuessingGame(int max)
        {
            ArrayList guesses = new ArrayList();
            int lives = 5;
            int randomNum = rand.Next(1, max+1);
            do
            {
                if (lives < 1)
                {
                    Console.WriteLine($"You ran out of lives. The correct number was {randomNum}");
                    break;
                }
                long input = TakeLongInput($"\nPlease enter your guess from 1 to {max}", 1, max);
                if (input == randomNum)
                {
                    PlayBeep(true);
                    Console.WriteLine("You guessed correctly!!!");
                    break;
                }
                else if (input < randomNum)
                {
                    if (guesses.Contains(input))
                    {
                        Console.WriteLine("That guess has already been entered");
                        PlayBeep(false);
                    }
                    else {
                        PlayBeep(false);
                        Console.WriteLine("Your guess was too low.");
                        guesses.Add(input);
                        lives -= 1;
                    }
                }
                else
                {
                    if (guesses.Contains(input))
                    {
                        PlayBeep(false);
                        Console.WriteLine("That guess has already been entered");
                    }
                    else
                    {
                        PlayBeep(false);
                        Console.WriteLine("Your guess was too high.");
                        guesses.Add(input);
                        lives -= 1;
                    }
                }

                Console.WriteLine($"{lives} lives remaing. Previous guesses-");
                foreach (var i in guesses)
                {
                    Console.WriteLine($"    {i}");
                }
            } while (lives > -1);

        }
    }
}
