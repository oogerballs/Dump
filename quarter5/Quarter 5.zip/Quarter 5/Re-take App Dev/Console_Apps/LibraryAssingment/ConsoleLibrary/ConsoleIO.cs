﻿using System;

namespace ConsoleLibrary
{
    public class ConsoleIO
    {
       public static void StupidFunction()
        {
            Console.WriteLine("Hello");
        }

        public static int ReadInteger(string prompt, int min, int max)
        {
            bool validInput = false;
            int res;
            do
            {
            Console.WriteLine(prompt);
                string input = Console.ReadLine();
                int.TryParse(input, out res);
                
                if(res < min || res > max)
                {
                    Console.WriteLine("Your input was invalid");
                }
                else
                {
                    validInput = true;
                }

            } while (!validInput);
            


            return res;
        }


        //    public static T ReadValue<T>(string prompt,T min, T max)
        //{
        //    T result;

        //    return result;
        //}
    }

}
