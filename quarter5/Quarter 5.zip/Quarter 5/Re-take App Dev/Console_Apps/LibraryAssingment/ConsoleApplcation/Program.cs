﻿using System;
using ConsoleLibrary;
using ConsoleApplcation;

namespace ConsoleApplcation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadLine();
            ConsoleLibrary.ConsoleIO.StupidFunction();

            //ConsoleLibrary.ConsoleIO

        }
    }
}
