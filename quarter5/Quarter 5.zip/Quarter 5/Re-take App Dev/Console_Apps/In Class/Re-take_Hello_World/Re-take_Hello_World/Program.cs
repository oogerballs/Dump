﻿using System;

namespace IntroCore
{
	class Program
	{
		static void Main(string[] args)
		{
			//DataTypes.Display();
			//Strings.Display();
			//Arrays.Display();
			//Iteration.Display();
			//Methods.Display();
			//Enums.Display();
			//Structures.Display();
			//Nullable.Display();
			//ValueReference.Display();
			//Collections.Display();
			//Exceptions.Display();
			//Delegates.Display();
			//Events.Display();
			//Generics.Display();
			//Classes.Display();
			//Operators.Display();
			//Inheritances.Display();
			//Interfaces.Display();
			//ExtensionMethods.Display();
			//Anonymous.Display();
			//Lambda.Display();
			//Enumerable.Display();

			//Dynamic.Display();
			//Tuples.Display();
			//Asynchronous.Display();
			Linq.Display();

			Console.ReadLine();
		}

	}
}
