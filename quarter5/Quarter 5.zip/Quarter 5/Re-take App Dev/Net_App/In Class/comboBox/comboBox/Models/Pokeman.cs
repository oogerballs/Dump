﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace comboBox.Models
{
    public class Pokeman
    {
        public enum stype
        {
            DARK,
            FIRE
        }
        public string Name { get; set; }
        public stype Type { get; set; }
        public int Tndex { get; set; }
    }
}
