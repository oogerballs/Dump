﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using comboBox.Models;

namespace comboBox
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            string[] drinks = { "Powerade", "Fanta","Water","Dr. Pepper"};
            foreach(string drink in drinks)
            {
                DrinksCombobox.Items.Add(drink);
            }

            List<Pokeman> pokemans = new List<Pokeman>
            {
                new Pokeman {Name = "zigzagaragoo", Type = Pokeman.stype.DARK, Tndex = 1},
                new Pokeman {Name = "Sableye", Type = Pokeman.stype.DARK, Tndex = 13442},
                new Pokeman {Name = "packerjew", Type = Pokeman.stype.FIRE, Tndex = 5}
            };
            PokemansComboBox.ItemsSource = pokemans;

            ColorComboBox.ItemsSource = typeof(Colors).GetProperties();
            ColorComboBox.SelectedIndex = 0;
        }

        private void AddDrinkButton_Click(object sender, RoutedEventArgs e)
        {
            DrinksCombobox.Items.Add(DrinkEntry.Text);
            DrinkEntry.Clear();
        }

        private void RemoveDrinkButton_Click(object sender, RoutedEventArgs e)
        {
            var selection = DrinksCombobox.SelectedItem;
            if(selection != null)
            {
                DrinksCombobox.Items.RemoveAt(DrinksCombobox.Items.IndexOf(selection));
            }
        }
    }
}
