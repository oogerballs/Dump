﻿using MasterMind.Models;
using MasterMind.UserControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MasterMind
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        Random random = new Random();
        public List<Peg> answerPegs = new List<Peg>();
        public int numRows { get; set; } = 3;
        public int numPegs { get; set; } = 5;
        public int CurrentRow { get; set; }
        public int NumPlayers;
        public int currentPlayer;
        public List<int> playerScores = new List<int>();

        public MainWindow()
        {
            InitializeComponent();
            CurrentRow = numRows - 1;
        }

        private void ResetAnswer()
        {
            answerPegs.Clear();
            AnswerPanel.Children.Clear();

            for (int i = 0; i < numPegs; i++)
            {
                Peg peg = new Peg();
                peg.Color = (Peg.Colors)random.Next(1, (int)Peg.Colors.Num_Colors);
                answerPegs.Add(peg);
            }

            PegButtonContainerControl pegContainer = new PegButtonContainerControl(answerPegs);
            AnswerPanel.Children.Add(pegContainer);
        }

        private void Reset()
        {
            CurrentRow = numRows - 1;
            SelectionPanel.Children.Clear();
            for (int i = 0; i < numRows; i++)
            {
                List<Peg> pegs = new List<Peg>();
                for (int j = 0; j < numPegs; j++) pegs.Add(new Peg());

                PegButtonContainerControl pegContainer = new PegButtonContainerControl(pegs);
                SelectionPanel.Children.Add(pegContainer);
            }

            HintPanel.Children.Clear();
            for (int i = 0; i < numRows; i++)
            {
                List<Peg> pegs = new List<Peg>();
                for (int j = 0; j < numPegs; j++) pegs.Add(new Peg());

                PegContainerControl pegContainer = new PegContainerControl(pegs);
                HintPanel.Children.Add(pegContainer);
            }
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            PegButtonContainerControl pegContainer = (PegButtonContainerControl)SelectionPanel.Children[CurrentRow];
            List<Peg> selectPegs = pegContainer.Pegs;

            //PegContainerControl answerPegContainer = (PegContainerControl)HintPanel.Children[CurrentRow];
            //List<Peg> answerPegs = pegContainer.Pegs;


            List<Peg> selectPegsCopy = new List<Peg>();
            selectPegs.ForEach((item) => { selectPegsCopy.Add((Peg)item.Clone()); });

            List<Peg> answerPegsCopy = new List<Peg>();
            answerPegs.ForEach((item) => { answerPegsCopy.Add((Peg)item.Clone()); });



            int hintIndex = 0;
            for (int i = 0; i < selectPegsCopy.Count; i++)
            {
                if (selectPegsCopy[i].Color == answerPegsCopy[i].Color)
                {
                    selectPegsCopy[i].Color = Peg.NULL_COLOR;
                    answerPegsCopy[i].Color = Peg.NULL_COLOR;

                    PegContainerControl pegHintContainer = (PegContainerControl)HintPanel.Children[CurrentRow];
                    pegHintContainer.Pegs[hintIndex].Color = Peg.CORRECT_COLOR_POSITION;
                    hintIndex++;
                }
            }

            for (int i = 0; i < selectPegsCopy.Count; i++)
            {
                for (int j = 0; j < answerPegsCopy.Count; j++)
                {
                    if (selectPegsCopy[i].Color != Peg.NULL_COLOR && selectPegsCopy[i].Color == answerPegsCopy[j].Color)
                    {
                        selectPegsCopy[i].Color = Peg.NULL_COLOR;
                        answerPegsCopy[j].Color = Peg.NULL_COLOR;

                        PegContainerControl pegHintContainer = (PegContainerControl)HintPanel.Children[CurrentRow];
                        pegHintContainer.Pegs[hintIndex].Color = Peg.CORRECT_COLOR;
                        hintIndex++;

                    }
                }
            }

            //List<Peg> pegs = pegContainer.Pegs;

            //int hintIndex = 0;
            //for (int i = 0; i < pegs.Count; i++)
            //{
            //    for (int j = 0; j < answerPegs.Count; j++)
            //    {
            //        if (pegs[i].Color == answerPegs[j].Color)
            //        {
            //            PegContainerControl hintContainer = (PegContainerControl)HintPanel.Children[CurrentRow];
            //            hintContainer.Pegs[hintIndex].Color = (i == j) ? Peg.CORRECT_COLOR_POSITION : Peg.CORRECT_COLOR;
            //            hintIndex++;
            //            break;
            //        }
            //    }
            //}
            CurrentRow--;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Reset();
            ResetAnswer();
        }


        private void VisableBUtton_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            if (AnswerPanel.Visibility == Visibility.Visible)
            {
                AnswerPanel.Visibility = Visibility.Collapsed;
                button.Content = "Show";
            }
            else
            {
                AnswerPanel.Visibility = Visibility.Visible;
                button.Content = "Hide";

            }
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            Reset();
            ResetAnswer();
        }

        private void OptionsCheckBox_Click(object sender, RoutedEventArgs e)
        {
            if (OptionsCheckBox.IsChecked == true)
            {
                OptionsBox.Visibility = Visibility.Visible;
            }
            else
            {
                OptionsBox.Visibility = Visibility.Collapsed;
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox CB = (ComboBox)sender;
            NumPlayers = CB.SelectedIndex;
        }

        private void ResetPlayers()
        {
            PlayerPanel.Children.Clear();
            playerScores.Clear();

            for (int i = NumPlayers; i < playerScores.Count; i++)
            {
                playerScores.Add(new int());
            }

            for (int i = 0; i < playerScores.Count; i++)
            {
                TextBlock textBlock = new TextBlock();
                textBlock.Foreground = new SolidColorBrush(Colors.White);
                textBlock.Text = "Player " + (i + 1) + ": " + playerScores[i].ToString("D4");
                PlayerPanel.Children.Add(textBlock);
            }
        }

        private void SetButton_Click(object sender, RoutedEventArgs e)
        {
            numRows = (int)RowSlider.Value;
            numPegs = (int)ColumnSlider.Value;

            Reset();
            ResetAnswer();
        }
    }
}
