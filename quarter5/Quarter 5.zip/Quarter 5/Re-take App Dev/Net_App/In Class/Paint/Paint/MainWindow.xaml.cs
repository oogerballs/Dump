﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Wpf.Toolkit;

namespace Paint
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void DrawButton_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void DrawButton_Click(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = (RadioButton)sender;
            String name = radioButton.Name;
            switch(name){
                case "DrawButton":
                    this.DrawingCanvas.EditingMode = InkCanvasEditingMode.Ink;
                    break;
                case "EraseButton":
                    this.DrawingCanvas.EditingMode = InkCanvasEditingMode.EraseByPoint;
                    break;
                case "SelectButton":
                    this.DrawingCanvas.EditingMode = InkCanvasEditingMode.Select;
                    break;
            }
        }

        private void SetBrushSize(object sender)
        {
            string text = ((ComboBox)sender).Text;
            if (text != "")
            {
                int size;
                int.TryParse(text, out size);

                BrushAttrib.Width = size;
                BrushAttrib.Height = size;

            }
        }

        private void BrushSize_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SetBrushSize(sender);
        }

        private void BrushSize_DropDownClosed(object sender, EventArgs e)
        {
            SetBrushSize(sender);
        }

        private void Color_SelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color?> e)
        {
            ColorPicker cP = (ColorPicker)sender;

            if (cP != null)
            {
                BrushAttrib.Color = (Color)cP.SelectedColor;
            }
        }
    }
}
