// $('.box').on('click', function(){
//     $(this).toggleClass('is-paused');
// });

// $(document).ready(function(){
//     $('.DropMenu').hide();
//     $('#Menu').on('click', function(){
//         $('.DropMenu').fadeIn('slow');
//     })
// });


function openNav(){
    document.getElementById('theSideNav').style.width = '150px';
    document.getElementById('test').style.marginLeft = '150px';
    document..style.backgroundColor = "rgba(0,0,0,.6)";
}

function closeNav(){
    document.getElementById('theSideNav').style.width = '0';
    document.getElementById("test").style.marginLeft = "0";
    document.body.style.backgroundColor = "rgba(10,60,150,0)";
}