
// Menu Navigation
function openNav(){
    document.getElementById('theSideNav').style.width = '150px';
    document.getElementById('menu').style.marginLeft = '150px';
    document.body.style.backgroundColor = "rgba(0,0,0,.6)";
}

function closeNav(){
    document.getElementById('theSideNav').style.width = '0';
    document.getElementById("menu").style.marginLeft = "0";
    document.body.style.backgroundColor = "white";
}
// Menu Navigation end