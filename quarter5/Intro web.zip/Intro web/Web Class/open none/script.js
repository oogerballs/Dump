var answer1 = document.getElementById('answer1');

function clicked(evt){
    console.log(evt.target.id);
    answer1.style.display = 'none';
}

function clicked2(evt){
    console.log(evt.target.id);
    answer1.style.display = 'block';
}


answer1.addEventListener('click', clicked);