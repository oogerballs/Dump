function Name(){
    var Welcome =  document.getElementById('Welcome');
    var TheName = document.forms.myForm.inputBox.value;
    correct.innerHTML = TheName;
    var guess = theName;
    var correct =document.getElementById('correct');
    return false;
}                  
var stuff = document.getElementById('stuff');
var randomNumber = Math.floor(Math.random()*15);

