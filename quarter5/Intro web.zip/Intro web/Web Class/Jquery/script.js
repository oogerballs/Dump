$(document).ready(function(){
    $('#content1').hide();
    $('#content1').fadeIn('slow', function(){
        $('#content1').fadeOut('slow');
    });

    $('#content2').css({
        'background-color': '#000', 
        'width':400});

        $('#content2').on('click',function(){
           $('#content1').toggle(); 
        });
        var threeBig = false;
        $('#content3').on('dblclick', function(){
            if(threeBig){
                $(this).height('50px');
                $(this).width('50px');
                threebig = false;
            }else{
                $(this).height('150px');
                $(this).width('150px');
                threeBig = true;
            }
        });
        $('#content4').on('mouseover',function(){
            $(this).html('hello');
        });
        $('#content4').on('mouseout',function(){
            $(this).html('Cya');
        });
        $('#content5').on('mousedown',function(){
            $(this).html('Hey!');
            $(this).width('100px');
        });
        $('#content5').on('mouseup',function(){
            $(this).html('5');
            $(this).width('50px');          
        });
        $('#content6').on('click',function(){
            $('#content1').show();
            $('#content1').html('A');
            $('#content1').css({
                'background-color': '#004',
                'width':50,
                'height':50
            });
            $('#content2').show();
            $('#content2').html('B');
            $('#content2').css({
                'background-color': '#006',
                'width':50,
                'height':50
            });
            $('#content3').show();
            $('#content3').html('C');
            $('#content3').css({
                'background-color': '#008',
                'width':50,
                'height':50
            });
            $('#content4').show();
            $('#content4').html('D');
            $('#content4').css({
                'background-color': '#00a',
                'width':50,
                'height':50
            });
            $('#content5').show();
            $('#content5').html('E');
            $('#content5').css({
                'background-color': '#00c',
                'width':50,
                'height':50
            });
            $('#content6').show();
            $('#content6').html('F');
            $('#content6').css({
                'background-color': '#00e',
                'width':50,
                'height':50
            });
        });
});