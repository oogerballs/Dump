var ctx =  document.geetElementById("myCanvas").getContext('2d');

var graph = new BarGraph(ctx);
graph.marnin = 2;
graph.width = 450;
graph.height = 150;
graph.xAxisLabelArr = ['Stuff',"Duff", "fuck"];
graph.update([3, 5, 3]);

function BarGraph(ctx) {
    var that = this;
    var startArr;
    var endArr;
    var looping = false;

}

// myCanvas.width = 300;
// myCanvas.height = 300;
  
// var ctx = myCanvas.getContext("2d");

// function drawLine(ctx, startX, startY, endX, endY, color){
//     ctx.save();
//     ctx.strokeStyle = color;
//     ctx.beginPath();
//     ctx.moveTo(startX,startY);
//     ctx.lineTo(endX,endY);
//     ctx.stroke();
//     ctx.restore();
// }

// function drawBar(ctx,upperLeftConerX, upperLeftCornerY, width, height, colo){
//     ctx.save();
//     ctx.fillStyle = color;
//     ctx.fillRect(upperLeftConerX, upperLeftCornerY, width, height);
//     ctx.restore();
// }

// var bars = {
//     "my Nibba Trace": 15,
//     "Their Nibba dic": 10,
//     "Rando Bando": 2,
//     "Jizzy Jacoodle": 28
// };

// var Barchart = function(options){
//     this.options = options;
//     this.canvas = options.canvas;
//     this.ctx = this.canvas.getContext("2d");
//     this.colors = options.colors;

//     this.draw = function(){
//         var maxValue = 0;
//         for (var categ in this.options.data){
//             maxValue = Math.max(maxValue,this.options.data[categ]);
//         }
//         var canvasHeight = this.canvas.height - this.options.padding * 2;
//         var canvasWidth = this.canvas.width - this.options.padding * 2;
        
//     //draw grid lines
//         var gridValue = 0;
//         while (gridValue <= maxValue){
//             var gridY = canvasHeight * (1 - gridValue/maxValue) +this.options.papdding;
//             drawLine(
//                 this.ctx,
//                 0,
//                 gridY,
//                 this.canvas.width,
//                 gridY,
//                 this.options,gridColor
//             );

//     //Drawing grid markers
//     this.cyx.save();
//     this.ctx.fillStyle = this.options.gridColor;
//     this.ctx.font = "bold 10px Time New Roman";
//     this.ctx.fillText(gridValue, 10, gridY - 2);
//     this.ctx.restore();

//     gridValue+=this.options.gridScale;
//         }

//         //Drawing bars
//         var barIndex = 0;
//         var numberOfBars = object.keys(this.options.data).length;
//         var barSize = (canvasActualWidth)/numberOfBars;

//         for (categ in this.options.data){
//             var val = this.options.data[categ];
//             var barHeight = Math.round( canvasHeight * val/maxValue);
//             drawBar(
//                 this.ctx,
//                 this.options.padding + barIndex * barSize,
//                 this.canvas.height - barHeight - this.options.padding,
//                 barSize,
//                 barHeight,
//                 this.colors[barIndex%this.color.length]
//             );
//             barIndex++;
//         }
//     }
// }

// var myBarchart = new Barchart(
//     {
//         canvas:myCanvas,
//         padding:10,
//         gridscale:5,
//         gridColor:"eeeeee",
//         data: myVinyls,
//         colors: ["#a55ca5","#67b6c7", "bccd7a", "#eb9743"]
//     }
// );
// myBarchart.draw();



