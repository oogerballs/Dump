var weatherData;
var request = new XMLHttpRequest();
var date = new Date();

loadData();

function loadData() {
    
    request.open('GET', 'https://api.weatherbit.io/v2.0/forecast/daily?city=Salt+Lake+City,US&units=I&key=e7b64f32498543269efe7d9df3ad7d60');
    request.onload = loadComplete;
    request.send();
}

function loadComplete(evt) {
    weatherData = JSON.parse(request.responseText);

    //frist Day
    console.log(weatherData);
    document.getElementById("location").innerHTML = "Day 1: " + weatherData.city_name + ", " + weatherData.state_code;
    document.getElementById("day").innerHTML = weatherData.data[0].datetime;
    document.getElementById("currentTemp").innerHTML = "Lowest Temperature: " +weatherData.data[0].app_min_temp+" Highest Temperature: "+ weatherData.data[0].max_temp;
    document.getElementById("conditionsDesc").innerHTML = weatherData.data[0].weather.description;  
    if(weatherData.data[0].weather.description == "Scattered clouds"){
        $(".Icon").attr("src","ScrCloud.jpg");
    }else if(weatherData.data[0].weather.description == "Broken clouds"){
        $(".Icon").attr("src","BrokenCloudsIcon.jpg");
    }else if(weatherData.data[0].weather.description == "Clear sky"){
        $(".Icon").attr("src","ClearSkyIcon.jpg");
    }else if(weatherData.data[0].weather.description == "Snow"){
        $(".Icon").attr("src","SnowIcon.jpg");
    }else if(weatherData.data[0].weather.description == "rain"){
        $(".Icon").attr("src","RainIcon.jpg");
    }

    //second Day
    document.getElementById("location2").innerHTML = "Day 2: " + weatherData.city_name + ", " + weatherData.state_code;
    document.getElementById("day2").innerHTML = weatherData.data[1].datetime;
    document.getElementById("currentTemp2").innerHTML = "Lowest Temperature: " + weatherData.data[1].app_min_temp + " Highest Temperature: " + weatherData.data[1].max_temp;
    document.getElementById("conditionsDesc2").innerHTML = weatherData.data[1].weather.description;
    if(weatherData.data[1].weather.description == "Scattered clouds"){
        $(".Icon2").attr("src","ScrCloud.jpg");
    }else if(weatherData.data[1].weather.description == "Broken clouds"){
        $(".Icon2").attr("src","BrokenCloudsIcon.jpg");
    }else if(weatherData.data[1].weather.description == "Clear sky"){
        $(".Icon2").attr("src","ClearSkyIcon.jpg");
    }else if(weatherData.data[1].weather.description == "Snow"){
        $(".Icon2").attr("src","SnowIcon.jpg");
    }else if(weatherData.data[1].weather.description == "rain"){
        $(".Icon2").attr("src","RainIcon.jpg");
    }

    //Third Day
    document.getElementById("location3").innerHTML ="Day 3: " + weatherData.city_name + ", " + weatherData.state_code;
    document.getElementById("day3").innerHTML = weatherData.data[2].datetime;
    document.getElementById("currentTemp3").innerHTML = "Lowest Temperature: " + "\n"+ weatherData.data[2].app_min_temp + " Highest Temperature: " + weatherData.data[2].max_temp;
    document.getElementById("conditions3").innerHTML = weatherData.data[2].weather.description;
    if(weatherData.data[2].weather.description == "Scattered clouds"){
        $(".Icon3").attr("src","ScrCloud.jpg");
    }else if(weatherData.data[2].weather.description == "Broken clouds"){
        $(".Icon3").attr("src","BrokenCloudsIcon.jpg");
    }else if(weatherData.data[2].weather.description == "Clear sky"){
        $(".Icon3").attr("src","ClearSkyIcon.jpg");
    }else if(weatherData.data[2].weather.description == "Snow"){
        $(".Icon3").attr("src","SnowIcon.jpg");
    }else if(weatherData.data[2].weather.description == "rain"){
        $(".Icon3").attr("src","RainIcon.jpg");
    }

    //Fourth Day
    document.getElementById("location4").innerHTML ="Day 4: " + weatherData.city_name + ", " + weatherData.state_code;
    document.getElementById("day4").innerHTML = weatherData.data[3].datetime;
    document.getElementById("currentTemp4").innerHTML = "Lowest Temperature: " + weatherData.data[3].app_min_temp + " Highest Temperature: "+ weatherData.data[3].max_temp;
    document.getElementById("conditions4").innerHTML = weatherData.data[3].weather.description;
    if(weatherData.data[3].weather.description == "Scattered clouds"){
        $(".Icon4").attr("src","ScrCloud.jpg");
    }else if(weatherData.data[3].weather.description == "Broken clouds"){
        $(".Icon4").attr("src","BrokenCloudsIcon.jpg");
    }else if(weatherData.data[3].weather.description == "Clear sky"){
        $(".Icon4").attr("src","ClearSkyIcon.jpg");
    }else if(weatherData.data[3].weather.description == "Snow"){
        $(".Icon4").attr("src","SnowIcon.jpg");
    }else if(weatherData.data[3].weather.description == "rain"){
        $(".Icon4").attr("src","RainIcon.jpg");
    }

    //Fifth Day
    document.getElementById("location5").innerHTML ="Day 5: " + weatherData.city_name + ", " + weatherData.state_code;
    document.getElementById("day5").innerHTML = weatherData.data[4].datetime;
    document.getElementById("currentTemp5").innerHTML = "Lowest temperature: " + weatherData.data[4].app_min_temp + " Highest temperature: "+ weatherData.data[4].max_temp;
    document.getElementById("conditions5").innerHTML = weatherData.data[4].weather.description;
    if(weatherData.data[4].weather.description == "Scattered clouds"){
        $(".Icon5").attr("src","ScrCloud.jpg");
    }else if(weatherData.data[4].weather.description == "Broken clouds"){
        $(".Icon5").attr("src","BrokenCloudsIcon.jpg");
    }else if(weatherData.data[4].weather.description == "Clear sky"){
        $(".Icon5").attr("src","ClearSkyIcon.jpg");
    }else if(weatherData.data[4].weather.description == "Snow"){
        $(".Icon5").attr("src","SnowIcon.jpg");
    }else if(weatherData.data[4].weather.description == "rain"){
        $(".Icon5").attr("src","RainIcon.jpg");
    }
};

//JQ
$(document).ready(function(){

    $('#moreInfo').hide();
    $('#forcast').on('click', function(){
        $('#click').hide();
        $(this).removeClass('forcast')
        $(this).addClass('add');
        $('#moreInfo').fadeIn('slow');
        $('#forcast2').removeClass('add');
          $('#moreInfo2').hide();
          $('#click2').fadeIn('slow');
        $('#forcast3').removeClass('add');
          $('#moreInfo3').hide();
          $('#click3').fadeIn('slow');
        $('#forcast4').removeClass('add');
          $('#moreInfo4').hide();
          $('#click4').fadeIn('slow');
        $('#forcast5').removeClass('add');
          $('#moreInfo5').hide();
          $('#click5').fadeIn('slow');
        
    }); 
    $('#forcast').on('mouseover',function(){
        $(this).css('background-color', "#41757c");
    });
    $('#forcast').on('mouseout',function(){
        $(this).css('background-color', "#41759c");
    });

    

    //FORCAST NO.2
    $('#moreInfo2').hide();
    $('#forcast2').on('click', function(){
        $('#click2').hide();
        $('#moreInfo2').fadeIn('slow');
        $(this).addClass('add');
        $('#forcast').removeClass('add');
          $('#moreInfo').hide();
          $('#click').fadeIn('slow');
        $('#forcast3').removeClass('add');
          $('#moreInfo3').hide();
          $('#click3').fadeIn('slow');
        $('#forcast4').removeClass('add');
          $('#moreInfo4').hide();
          $('#click4').fadeIn('slow');
        $('#forcast5').removeClass('add');
          $('#moreInfo5').hide();
          $('#click5').fadeIn('slow');
    });
    $('#forcast2').on('mouseover',function(){
        $(this).css('background-color', "#41757c");
    });
    $('#forcast2').on('mouseout',function(){
        $(this).css('background-color', "#41759c");
    });

    //FORCAST NO.3
    $('#moreInfo3').hide();
    $('#forcast3').on('click', function(){
        $('#click3').hide();
        $('#moreInfo3').fadeIn('slow');
        $(this).addClass('add');
        $('#forcast').removeClass('add');
          $('#moreInfo').hide();
          $('#click').fadeIn('slow');
        $('#forcast2').removeClass('add');
          $('#moreInfo2').hide();
          $('#click2').fadeIn('slow');
        $('#forcast4').removeClass('add');
          $('#moreInfo4').hide();
          $('#click4').fadeIn('slow');
        $('#forcast5').removeClass('add');
          $('#moreInfo5').hide();
          $('#click5').fadeIn('slow');
    }); 
    $('#forcast3').on('mouseover',function(){
        $(this).css('background-color', "#41757c");
    });
    $('#forcast3').on('mouseout',function(){
        $(this).css('background-color', "#41759c");
    });


    //FORCAST NO.4
    $('#moreInfo4').hide();
    $('#forcast4').on('click', function(){
        $('#click4').hide();
        $('#moreInfo4').fadeIn('slow');
        $(this).addClass('add');
        $('#forcast').removeClass('add');
          $('#moreInfo').hide();
          $('#click').fadeIn('slow');
        $('#forcast2').removeClass('add');
          $('#moreInfo2').hide();
          $('#click2').fadeIn('slow');
        $('#forcast3').removeClass('add');
          $('#moreInfo3').hide();
          $('#click3').fadeIn('slow');
        $('#forcast5').removeClass('add');
          $('#moreInfo5').hide();
          $('#click5').fadeIn('slow');
    }); 
    $('#forcast4').on('mouseover',function(){
        $(this).css('background-color', "#41757c");
    });
    $('#forcast4').on('mouseout',function(){
        $(this).css('background-color', "#41759c");
    });

    // FORCAST NO.5
    $('#moreInfo5').hide();
    $('#forcast5').on('click', function(){
        $('#click5').hide();
        $('#moreInfo5').fadeIn('slow');
        $(this).addClass('add');
        $('#forcast').removeClass('add');
          $('#moreInfo').hide();
          $('#click').fadeIn('slow');
        $('#forcast2').removeClass('add');
          $('#moreInfo2').hide();
          $('#click2').fadeIn('slow');
        $('#forcast3').removeClass('add');
          $('#moreInfo3').hide();
          $('#click3').fadeIn('slow');
        $('#forcast4').removeClass('add');
          $('#moreInfo4').hide();
          $('#click4').fadeIn('slow');
    }); 
    $('#forcast5').on('mouseover',function(){
        $(this).css('background-color', "#41757c");
    });
    $('#forcast5').on('mouseout',function(){
        $(this).css('background-color', "#41759c");
    });

});