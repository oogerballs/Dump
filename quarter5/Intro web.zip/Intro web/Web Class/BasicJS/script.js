var counter = 0;
var result = document.getElementById('result');
var randomNumber = Math.floor(Math.random()*99)+1;
console.log(randomNumber);
function f(){
  var input = document.forms.myForm.inputBox.value;
    if(input != randomNumber){
            if(input < 1 || input > 100 ){
                result.innerHTML="Invalid input, enter a number that is between 1 and 100.";
            }else if(input < randomNumber){
                result.innerHTML = "Your input was incorrect, you are guessing too low";
                counter += 1;
            }else if(input > randomNumber){
                result.innerHTML = "Your input was incorrect, your guess was too high";
                counter +=1;
            }else{
                result.innerHTML = "Invalid input, enter a number that is between 1 and 100."
                }
     }else if(input == randomNumber){
        result.innerHTML = "Your input was correct! The number was "+ randomNumber+ " and it took you "+(counter+1)+" try(s) to get it";
        window.open('gilles_ketting_400x400.jpg');
    }
        
return false;
}
