var canvas = document.getElementById('demo');
var ctx = canvas.getContext('2d');
 
// draw square
function drawSquare() {
  ctx.fillStyle = "rgb(100, 50, 200)";
  ctx.fillRect(10, 10, 30, 20);
}
drawSquare();
 
// draw rectangle outline
function drawBox() {
  ctx.strokeStyle = "rgb(100, 200, 100)";
  ctx.strokeRect(50,10,50,30);
}
drawBox();
 
// draw triangle
function drawTriangle() {
  ctx.fillStyle = "rgb(100, 180, 100)";
  ctx.beginPath();
  ctx.moveTo(150,10);
  ctx.lineTo(120,35);
  ctx.lineTo(150,60);
  ctx.fill();
}
drawTriangle();
 
// draw ellipse
function drawCircle() {
  ctx.strokeStyle = "rgb(200, 100, 100)";
  ctx.beginPath();
  ctx.ellipse(200, 40, 30, 30, 0, 0, 2 * Math.PI);
  ctx.stroke();  
}
drawCircle();
 
function getMousePos(canvas, evt) {
  var rect = canvas.getBoundingClientRect();
  return {
    x: evt.clientX - rect.left,
    y: evt.clientY - rect.top
  }
}
 
// listen for mouse movement in the canvas and output the values
canvas.addEventListener('mousemove', function(evt) {
  var mousePos = getMousePos(canvas, evt);
  document.getElementById("output").innerHTML = 'Mouse position: ' + mousePos.x + ',' + mousePos.y;
}, false);