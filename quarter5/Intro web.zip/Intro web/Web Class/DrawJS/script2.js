var canvas = document.getElementById('demo');
var ctx = canvas.getContext('2d');

ctx.strokeStyle = 'rbg(50,200,255)';
ctx.beginPath();
ctx.moveTo(0,300);
for(var i=0; i<=50; i++){
    ctx.lineTo(i*10,Math.random()*300   );
}
ctx.stroke();
ctx.closePath();