﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IxcameyC_Routing.Models
{
    public class MooModel
    {
        public int MooAmount { get; set; }
        public String MooReturn { get; set; }
    }
}