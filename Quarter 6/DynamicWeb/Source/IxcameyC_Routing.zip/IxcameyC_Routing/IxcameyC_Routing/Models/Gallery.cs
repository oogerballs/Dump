﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IxcameyC_Routing.Models
{
    public class Gallery
    {
        public String SlcCow { get; set; }
        public int Amount { get; set; }
        public int PageNo { get; set; }
    }
}