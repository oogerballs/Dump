﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IxcameyC_Routing.Models
{
    public class CowModel
    {
        public String Name { get; set; }
        public int MooCount { get; set; }
    }
}