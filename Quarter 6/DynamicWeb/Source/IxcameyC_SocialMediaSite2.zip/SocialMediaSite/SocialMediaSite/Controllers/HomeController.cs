﻿using SocialMediaSite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SocialMediaSite.Controllers
{
    public class HomeController : Controller
    {
        ISocialMediaService service = new EFSocialMediaService();
        public ActionResult Index()
        {
            var model = service.GetNewsFeed(5);
            return View(model);
        }

        public new ActionResult Profile()
        {
            var model = service.GetProfile();
            return View(model);
        }

        public  ActionResult Imagedetail(int id = 0)
        {
            var model = service.GetImageById(id);
            return View(model);
        }

        public ActionResult Gallery()
        {
            var model = service.GetGalleryList();
            return View(model);
        }

        public ProfileModel CreateUser()
        {
            Dictionary<string, string> favs = new Dictionary<string, string>
            {
                { "Book", "The Silent Girls" },
                { "Game", "Left 4 Dead 2" },
                { "Movie", "Logan" }
            };
            ProfileModel profile = new ProfileModel()
            {
                Id = 1,
                ProfileName = "Cristian Ixcamey",
                NickName = "ooger",
                ProfileImageUrl = "https://images.pexels.com/users/avatars/424770/cristian-ixcamey-347.jpeg?w=256&h=256&fit=crop&crop=faces",

            };
            return profile;
        }
        public RedirectToRouteResult Delete(int id)
        {
            service.DeleteImageById(id);
            return RedirectToAction("Gallery");
        }

        [HttpGet]
        public ViewResult CreateImage()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateImage(Models.Image model)
        {
            GalleryList list = service.GetGalleryList();
            model.ImageId = list.Images.Count+1;
            service.CreateImage(model);
            return RedirectToAction("Gallery", "Home", new { });
        }

        [HttpGet]
        public ViewResult UpdateImage(Models.Image model)
        {
            return View(model);
        }

        [HttpPost]
        public ActionResult updateImage(Models.Image model)
        {
            service.UpdateImage(model);
            return RedirectToAction("Gallery","home");
        }
    }
}