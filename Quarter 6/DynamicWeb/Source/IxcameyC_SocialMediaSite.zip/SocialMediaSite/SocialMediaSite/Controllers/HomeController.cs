﻿using SocialMediaSite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SocialMediaSite.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public new ActionResult Profile()
        {
           
                
            return View(CreateUser());
        }

        public ActionResult Gallery()
        {
            
            return View(CreateUser());
        }

        public ProfileModel CreateUser()
        {
            Dictionary<string, string> favs = new Dictionary<string, string>
            {
                { "Book", "The Silent Girls" },
                { "Game", "Left 4 Dead 2" },
                { "Movie", "Logan" }
            };
            ProfileModel profile = new ProfileModel()
            {
                Id = 1,
                ProfileName = "Cristian Ixcamey",
                NickName = "ooger",
                ProfileImageUrl = "https://images.pexels.com/users/avatars/424770/cristian-ixcamey-347.jpeg?w=256&h=256&fit=crop&crop=faces",
                Favorites = favs,
                ImageList = new List<GalleryImageModel>()
                {                   
                    new GalleryImageModel(){
                        ImageName = "Gilles 1",
                        ImgSrc = "https://cdna.artstation.com/p/assets/images/images/000/554/172/large/gilles-ketting-af-int-pianoroom-a02.jpg?1426610161",
                        Caption = "caption 1"
                    },
                    new GalleryImageModel(){
                        ImageName = "Gilles 2",
                        ImgSrc = "https://cdnb.artstation.com/p/assets/images/images/000/129/315/large/gilles-ketting-nightwatch-boltonbetterrun-gillesketting2.jpg?1404924352",
                        Caption = "caption 2"
                    },
                    new GalleryImageModel(){
                        ImageName = "Gilles 3",
                        ImgSrc = "http://4.bp.blogspot.com/-2XuiDfx2ue0/UEEAPGUUzlI/AAAAAAAAAtA/Z5AZlWVqMvA/s1600/SilentHill_EvokedFromTheMist_GillesKetting.jpg",
                        Caption = "caption 3"
                    },
                    new GalleryImageModel(){
                        ImageName = "Gilles 4",
                        ImgSrc =  "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/intermediary/f/8dd932fe-a7c3-4925-81f9-e171d492f938/d9nx9p0-712306f3-9935-4658-92bc-1e0b8cee8c5a.jpg/v1/fill/w_500,h_244,q_70,strp/ashen_falls___theburninghouse_by_gillesketting_d9nx9p0-250t.jpg",
                        Caption = "caption 4"
                    },
                    new GalleryImageModel(){
                        ImageName = "Gilles 5",
                        ImgSrc = "https://pbs.twimg.com/media/DwzMGUyWoAUMbHh.jpg",
                        Caption = "caption 5"
                    },
                    new GalleryImageModel(){
                        ImageName = "Gilles 6",
                        ImgSrc = "https://i.ytimg.com/vi/yvIOs1h35G4/maxresdefault.jpg",
                        Caption = "caption 6"
                    }                   
                }                
            };
            return profile;
        }
    }
}