﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialMediaSite
{
    public class Favorites
    {
        public String FavType { get; set; }
        public String FavValue { get; set; }
    }
}