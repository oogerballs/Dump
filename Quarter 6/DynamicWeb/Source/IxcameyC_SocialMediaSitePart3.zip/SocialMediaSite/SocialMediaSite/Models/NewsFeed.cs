﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialMediaSite.Models
{
    public class NewsFeed
    {
        public String NewsHeader { get; set; }
        public String NewsImageUrl { get; set; }
        public String NewsBody { get; set; }
    }
}