export let MealPlanner = document.createElement("section");
export let request = new XMLHttpRequest();

let collapsableIndex = 2;

//MealPlanner code
export const createMealPlanner = _ => {
  //Creating search section
  let searchArea = document.createElement("section");
  searchArea.className = "Content";
  //Creating search area h1
  let searchAreaTitle = document.createElement("h1");
  searchAreaTitle.id = "SearchTitle";
  searchAreaTitle.innerText = "Search";
  searchArea.appendChild(searchAreaTitle);

  //Creating search instructions
  let SearchContent = document.createElement("section");
  SearchContent.className = "row";
  //Creating key word search bar
  let keywordEntry = document.createElement("INPUT");
  keywordEntry.id = "keywordEntry";
  keywordEntry.className = "TextEntry";
  keywordEntry.placeholder = "Exmp: Omelet";
  //Creating ingredient search bar
  let ingredientEntry = document.createElement("INPUT");
  ingredientEntry.id = "ingredientEntry";
  ingredientEntry.className = "TextEntry";
  ingredientEntry.placeholder = "Exmp: Onions,Garlic,Cheese";
  //Creating search button
  let SearchButton = document.createElement("button");
  SearchButton.id = "SearchButton";
  SearchButton.className = "button-standard";
  SearchButton.onclick = _ => {
    loadData(keywordEntry.value, ingredientEntry.value);
  };
  SearchButton.innerText = "Search Recipe";

  //Adding search bars and button to the search content
  SearchContent.appendChild(keywordEntry);
  SearchContent.appendChild(ingredientEntry);
  SearchContent.appendChild(SearchButton);
  //Adding search content to the search area
  searchArea.appendChild(SearchContent);
  //Adding search area to MealPlanner
  MealPlanner.appendChild(searchArea);
  // const

  let mealListSec = document.createElement("section");
  mealListSec.id = "MealListSec";
  MealPlanner.appendChild(mealListSec);
  MealPlanner.style.display = "none";

};

//RecipePuppy data
const loadData = (mealName, ingredients) => {
  let apiString = "?";
  if (mealName != "" && ingredients != "") {
    apiString += `i=${ingredients}&q=${mealName}`;
  } else if (ingredients != "") {
    apiString += `i=${ingredients}`;
  } else if (mealName != "") {
    apiString += `q=${mealName}`;
  }

  if (apiString == "?") {
    console.log("None of the things are valid");
  } else {
    request.open("GET", `http://www.recipepuppy.com/api/${apiString}`);
    request.onload = showData;
    request.send();
  }
};

const showData = _ => {
  //FOOD PLACEHOLDER https://i.pinimg.com/originals/fd/80/ec/fd80ecec48eba2a9adb76e4133905879.png
  let RecipeData = JSON.parse(request.responseText);
  let mealListSection = document.getElementById("MealListSec");
  mealListSection.innerHTML = "";
  let mealsList = RecipeData.results;
  if (mealsList == "") {
    mealListSection.innerHTML = `
    <section id="errorSection" class="Content-full">
      <section id="errorHeader">
      <i class="far fa-sad-cry fa-lg"></i> 
      <h1>There was an error!</h1>
      </section>
      <h3>The item you search for does not exist or is not supported. Please search for something else.</h3>
    </section>
    `;
  } else {
    collapsableIndex = 2;
    for (let i = 0; i < RecipeData.results.length; i += 2) {
      let mealImage1 = `<img src="${mealsList[i].thumbnail}" class"mealImages">`
      let mealImage2 = `<img src="${mealsList[i + 1].thumbnail}" class"mealImages">`
      if (mealsList[i].thumbnail == "") {
        mealImage1 = `<i class="foodIcon fas fa-utensils"></i>`;
      }
      if (mealsList[i + 1].thumbnail == "") {
        mealImage2 = `<i class=" foodIcon fas fa-utensils"></i>`;
      }
      const MealSectoions = `
            <section class="Content">
            <section class='row menuItem'>
            <button class='CollapsibleButton button-standard mealItem''>
            ${mealImage1}
                <h3>${mealsList[i].title}</h3>
            </button>
            <div class='CollapsibleContent'>
                <div class="Ingredients recipeContent">
                    <h4>
                    ${mealsList[i].ingredients}
                    </h4>
                </div>
                <div class="recipeLink recipeContent">
                    <h2>Link:</h2>
                    <a href="${mealsList[i].href}">${mealsList[i].href}</a>
                <div>
            </div>
        </section>
        <section class='row menuItem'>
            <button class='CollapsibleButton button-standard mealItem''>
            ${mealImage2}
                <h3>${mealsList[i + 1].title}'</h3>
            </button>
            <div class='CollapsibleContent'>
                <div class="Ingredients recipeContent">
                    <h4>
                    ${mealsList[i + 1].ingredients}
                    </h4>
                </div>
                <div class="recipeLink recipeContent">
                    <h2>Link:</h2>
                    <a href="${mealsList[i + 1].href}">${mealsList[i + 1].href}</a>
                <div>
            </div>
        </section>
            </section>
            `;
      mealListSection.innerHTML += MealSectoions;
    }

    let recipeCollection = document.getElementsByClassName("mealItem");
    for (let i = 0; i < recipeCollection.length; i++) {
      const colIndex = collapsableIndex;
      recipeCollection[i].onclick = _ => {
        CollapsibleToggle(colIndex);
      };
      collapsableIndex++;
    }
  }
};

const CollapsibleToggle = i => {

  i = i + 1;
  var CollapsibleContent = document.getElementsByClassName("CollapsibleContent");
  if (window.getComputedStyle(CollapsibleContent[i]).maxHeight == "0px") {
    CollapsibleContent[i].style.maxHeight = CollapsibleContent[i].scrollHeight + "px";
    CollapsibleContent[i].style.padding = "5%";
  } else {
    CollapsibleContent[i].style.maxHeight = null;
    CollapsibleContent[i].style.padding = "0%";
  }
};