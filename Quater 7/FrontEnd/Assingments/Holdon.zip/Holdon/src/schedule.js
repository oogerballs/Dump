const html = `
<section>
    <section class='Content-full'>
        <section class='row'>
            <button class='CollapsibleButton button-standard'>
            "Add Assignment"
            ::after
            </button>

            <div class='CollapsibleContent"> Section Here </div>

        </section>
    </section>
    <section class="Content-full AssignmentSections">
        <section class="Content sectionTitles">
            <h1>Over Due Assignments</h1>
        </section>
    </section>
    <section class="Content-full AssingmentSections" >
        <section class="Content sectionTitles">
            <h1>Upcoming Assignments</h1>
        </section>
    </section>
</section>
`;

let collapsableIndex = 0;
export var storage = [];
var assignmentName;
var dueDate;
var timeDue;
var points;
var inputValue = document.getElementsByClassName('thing');
export var submitbtn;
export var upcomingContent;
export var overdueContent;

export var Work = {
  Name: assignmentName,
  DueDate: dueDate,
  TimeDue: timeDue,
  Points: points
}


export let Scheduler = document.createElement("section");

export const setup = div => {
  div.innerHTML = html;
};

export const creatScheduler = _ => {
  //creating the 'Add Assingment' collapsable
  let AddAssingment = document.createElement("section");
  //Adding class to the AddAssingment section
  AddAssingment.className = "Content-full";

  //Creating the AddAssingmentCollapsible section and adding class name
  let AddAssingmentCollapsible = document.createElement("section");
  AddAssingmentCollapsible.className = "row";

  //Creating the AddAssingmentCollapsibleButton and adding class names
  let AddAssingmentCollapsibleButton = document.createElement("button");
  AddAssingmentCollapsibleButton.className =
    "CollapsibleButton button-standard";
  //Adding collapsible button onclick and inner text
  const index = collapsableIndex;
  AddAssingmentCollapsibleButton.onclick = function () {
    CollapsibleToggle(index);
  };
  collapsableIndex += 1;
  AddAssingmentCollapsibleButton.innerText = "Add Assingment";

  //Creating the AddAssingmentCollapsibleContent
  let AddAssingmentCollapsibleContent = document.createElement("div");
  //Adding AddAssingmentCollapsibleContent class name
  AddAssingmentCollapsibleContent.className = "CollapsibleContent";
  AddAssingmentCollapsibleContent.innerHTML =
    `<section class="Content-full">
      <section class="col">
        <input  class='thing' type='text' placeholder = 'Assignment Name'>
        <input   class='thing' type = 'date' placeholder = 'Due Date'>
        <input  class='thing' type = 'time' placeholder = 'Time Due'>
        <input class='thing' type='number' placeholder = 'Point Value'>
        <button id="sBtn" class"button-standard testButton">Submit</button>
      </section>
  </section>`;

  //Adding AddAssingmentCollapsibleButton & AddAssingmentCollapsibleContent to AddAssingmentCollapsible section
  AddAssingmentCollapsible.appendChild(AddAssingmentCollapsibleButton);
  AddAssingmentCollapsible.appendChild(AddAssingmentCollapsibleContent);
  //Adding AddAssingmentCollapsible section to the AddAssingment section
  AddAssingment.appendChild(AddAssingmentCollapsible);
  //Adding AddAssingment section to the Scheduler section
  Scheduler.appendChild(AddAssingment);

  //AddEventListener
  let inside = `<h4> Name</h4> <h4>Due Date</h4> <h4>Time Due</h4> <h4>Points</h4> `;
  var above = document.createElement('div');
  above.setAttribute('class', 'entry');
  above.innerHTML = inside;

  var above1 = document.createElement('div');
  above1.setAttribute('class', 'entry');
  above1.innerHTML = inside;

  //Creating Over Due Assingments section
  let OverDueSection = document.createElement("section");
  OverDueSection.className = "Content-full AssingmentSections ";
  OverDueSection.style.border = "1px solid red";

  //Collapsable Content
  overdueContent = document.createElement('div');
  overdueContent.setAttribute('class', 'CollapsibleContent other');
  overdueContent.appendChild(above1);

  let OverDueTitle = document.createElement("section");
  OverDueTitle.className = "Content sectionTitles sched CollapsibleButton";
  let OverDueTitleH1 = document.createElement("h1");
  OverDueTitleH1.innerHTML = "Over Due Assingments";
  OverDueTitle.appendChild(OverDueTitleH1);
  OverDueSection.appendChild(OverDueTitle);
  OverDueSection.appendChild(overdueContent);
  Scheduler.appendChild(OverDueSection);
  OverDueTitle.addEventListener('click', _ => {
    CollapsibleToggle(1);
  });

  //Creating Upcoming Assingments section
  let UpcomingSection = document.createElement("section");
  UpcomingSection.className = "Content-full AssingmentSections CollapsibleButton";
  UpcomingSection.style.border = "1px solid green";

  //Collapsable Content
  upcomingContent = document.createElement('div');
  upcomingContent.setAttribute('class', 'CollapsibleContent other');
  upcomingContent.appendChild(above);

  let UpcomingTitle = document.createElement("section");
  UpcomingTitle.className = "Content sectionTitles sched";
  let UpcomingTitleH1 = document.createElement("h1");
  UpcomingTitleH1.innerHTML = "Upcoming Assingments";
  UpcomingTitle.appendChild(UpcomingTitleH1);
  UpcomingSection.appendChild(UpcomingTitle);
  UpcomingSection.appendChild(upcomingContent);
  Scheduler.appendChild(UpcomingSection);
  UpcomingTitle.addEventListener('click', _ => {
    CollapsibleToggle(2);
  });

  //adding scheduler section to the app
  Scheduler.style.display = "none";


};

const hide = (evt) => {
  evt.style.display = "none";
}


window.onload = _ => {
  submitbtn = document.getElementById('sBtn');
  console.log(submitbtn);
  submitbtn.addEventListener('click', store);

  retrieve();
}

export var CollapsibleContent = document.getElementsByClassName("CollapsibleContent");

export const CollapsibleToggle = i => {
  if (CollapsibleContent != undefined) {
    if (window.getComputedStyle(CollapsibleContent[i]).maxHeight == "0px") {
      CollapsibleContent[i].style.maxHeight =
        CollapsibleContent[i].scrollHeight + 100 + "px";
      CollapsibleContent[i].style.padding = "10% 5%";
    } else {
      CollapsibleContent[i].style.maxHeight = null;
      CollapsibleContent[i].style.padding = "0%";
    }
  }
}

export const store = _ => {
  assignmentName = inputValue[0].value;
  dueDate = inputValue[1].value;
  timeDue = inputValue[2].value;
  points = inputValue[3].value;

  Work = {
    Name: assignmentName,
    DueDate: dueDate,
    TimeDue: timeDue,
    Points: points
  };

  let test = JSON.parse(localStorage.getItem('Work'));
  if (test !== null) {
    storage = JSON.parse(localStorage.getItem('Work'));
  }

  storage.push(Work);

  localStorage.setItem(`Work`, JSON.stringify(storage));
}

export const retrieve = () => {
  var homework = JSON.parse(localStorage.getItem('Work'));

  for (let i = 0; i < homework.length; i++) {
    const element = homework[i];

    var place = document.createElement('div');
    place.setAttribute('id', 'placer');

    var entry = document.createElement('div');
    let name = document.createElement('h4');
    let date = document.createElement('h4');
    let time = document.createElement('h4');
    let point = document.createElement('h4');
    // let del = document.createElement('div');

    // del.addEventListener('click',_=>{
    //   entry.innerHTML="";
    //   entry.style.display = "none";
    //   //localStorage.removeItem("Work");
    // });
    // del.setAttribute('class','btn');

    entry.setAttribute('class', 'entry');
    name.setAttribute('id', 'displayName');
    //  name.setAttribute('class','col');
    date.setAttribute('id', 'displayDate');
    //  date.setAttribute('class','col');
    time.setAttribute('id', 'displayTime');
    //  time.setAttribute('class','col');
    point.setAttribute('id', 'displayPoint');
    //  point.setAttribute('class','col');


    name.innerHTML = element.Name;
    date.innerHTML = element.DueDate;
    time.innerHTML = element.TimeDue;
    point.innerHTML = element.Points;
    // del.innerHTML = 'Delete';

    entry.appendChild(name);
    entry.appendChild(date);
    entry.appendChild(time);
    entry.appendChild(point);
    // entry.appendChild(del);

    place.appendChild(entry);


    let currentDate = new Date();
    let currentMonth = currentDate.getMonth();
    let currentDay = currentDate.getDate();
    let currentYear = currentDate.getFullYear();
    let fullDate;
    if (currentMonth < 10) {
      fullDate = `${currentYear}-0${currentMonth + 1}-0${currentDay}`;
      if (element.DueDate < fullDate) {
        console.log(place)
        overdueContent.appendChild(place);
      } else {

        upcomingContent.appendChild(place);
      }
    }
    else if (currentMonth > 9) {

      fullDate = `${currentYear}-${currentMonth + 1}-${currentDay}`;

      if (element.DueDate < fullDate) {
        console.log('Its working')
        OverDueSection.appendChild(place);
      } else {

        upcomingContent.appendChild(place);
      }
    }



  }

}

