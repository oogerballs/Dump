import * as MealPlanner from "./meal";
import * as Scheduler from "./schedule";

const app = document.getElementById('App');
var array = [];
document.head.innerHTML += `
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
`;

// let Scheduler = document.createElement("section");
// let MealPlanner = document.createElement("section");


const SetUp = _ => {
    document.body.className = "Content";

    //Creating header section
    let header = document.createElement("section");
    //adding class to header section
    header.className = "Content-full";

    //Create site banner
    let siteBanner = document.createElement("div");
    let siteBannerH1 = document.createElement("h1");
    //adding siteBanner class
    siteBanner.className = "Banner";
    //Adding text to site banner h1
    siteBannerH1.innerHTML = "Student Tools";
    //adding site banner h1 to the site banner
    siteBanner.appendChild(siteBannerH1);

    //Creating header buttons
    let SchedulerButton = document.createElement("button");
    let MealPlannerButton = document.createElement("button");
    //adding class to the header buttons
    SchedulerButton.className = "button-standard-dark";
    MealPlannerButton.className = "button-standard-dark";
    //Adding onclick to the buttons
    SchedulerButton.addEventListener("click", openScheduler);
    MealPlannerButton.addEventListener("click", openMealPlanner);
    //Adding content to the buttons
    SchedulerButton.innerHTML = "Scheduler";
    MealPlannerButton.innerHTML = "Meal Planner";

    //Adding Buttons to header
    header.appendChild(SchedulerButton);
    header.appendChild(MealPlannerButton);

    //Adding the Header, Scheduler, MealPlanner to the app
    app.appendChild(siteBanner);
    app.appendChild(header);
    Scheduler.creatScheduler();
    app.appendChild(Scheduler.Scheduler);
    MealPlanner.createMealPlanner();
    app.appendChild(MealPlanner.MealPlanner);

};

const openScheduler = _ => {
    MealPlanner.MealPlanner.style.display = "none";
    Scheduler.Scheduler.style.display = "block";
};

const openMealPlanner = _ => {
    Scheduler.Scheduler.style.display = "none";
    MealPlanner.MealPlanner.style.display = "block";
};




const show = num => {
    hide();

}

// var CollapsibleButton = document.getElementsByClassName('CollapsibleButton');
// console.log(CollapsibleButton);
// var CollapsibleContent = document.getElementsByClassName("CollapsibleContent");
// console.log(CollapsibleContent);

// const CollapsibleToggle = i => {
//     i -= 1;
//     console.log(CollapsibleContent[i].display);
//     if (window.getComputedStyle(CollapsibleContent[i]).maxHeight == "0px") {
//         CollapsibleContent[i].style.maxHeight = CollapsibleContent[i].scrollHeight + "px";
//         CollapsibleContent[i].style.padding = "5%";
//     } else {
//         CollapsibleContent[i].style.maxHeight = null;
//         CollapsibleContent[i].style.padding = "0%";
//     }
// };

SetUp();

// "@babel/core": "^7.0.1",
//     "@babel/preset-env": "^7.0.0",
//     "babel-loader": "^8.0.2",
//     "webpack": "^4.19.1",
//     "webpack-cli": "^3.1.1",
//     "webpack-dev-server": "^3.1.8"

// npm i --save-dev @babel/core @babel/preset-env babel-loader webpack webpack-cli
// webpack-dev-server

 var foot = document.createElement('footer');
 foot.innerHTML = `This website was made to accomodate the students of Neumont with college life.<br> It was made by Joshua Harrington, Cristian Ixcamey and Daniel Eastwood <br>&copy; Students of Neumont College of Computer Science`;
  app.appendChild(foot);
{/* <section id="CollapsibleSection" class="Content">
    <section class="row">
        <button class="CollapsibleButton button-standard" onclick="CollapsibleToggle(1)">
            Click to Open
        </button>
        <div class="CollapsibleContent">
            This is the content of the Collapsible. to hide this, simply click onm the collapsible button.
        </div>
    </section>
    </section> */}