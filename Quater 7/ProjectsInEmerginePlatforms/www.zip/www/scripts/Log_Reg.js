﻿document.getElementById("LoginButton").addEventListener("click", login);
document.getElementById("RegisterButton").addEventListener("click", register);

function login() {
    window.location.replace("pet.html");
};

function register() {
    window.location.replace("Register.html");
}